/***************************************************************
* vista.java
* Autor: Mariana David Sosa 201055
***************************************************************/

import java.util.Scanner;
import java.util.ArrayList;

class vista{
	Scanner scan;
	
	public vista(){
		scan = new Scanner(System.in);
	}


	public void press_enter(){
		System.out.println("\n Presione enter para continuar ");
		scan.nextLine();	
	}

	/***
	 * menu para elegir idioma
	 * @param idioma descripcion del idioma
	 * @return numero seleccionado segun el Idioma
	 */
	public int Menu(String idioma){
		boolean bandera=false;
		int op=-1;
		do{
			System.out.println(" Bienvenido, ingrese el idioma que desea utilizar "+idioma);
			System.out.println("	1.  English");
			System.out.println("	2.  Espanol");
			System.out.println("	3.  Frances");
			

			try{
			
				op = Integer.parseInt(scan.nextLine());

				
			}catch(Exception e){
				System.out.println("ERROR: porfavor ingrese un numero entero");
			}
			
			if(op<1||op>3){
				System.out.println("ERROR: porfavor ingrese un valor entero entre 1 y 3 \n");
			}else{
				bandera=true;
			}
		}while(bandera==false);
		
			return op;
	}

	
}