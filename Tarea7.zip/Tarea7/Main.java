/***
 * @author Mariana David Sosa 201055s
 */
/***
 * Imports necesarios para Main
 */

import java.util.Scanner;
import java.io.*;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Collections;
public class Main {
    public static  void main(String[] args){

        Traductor esperanza = new Traductor();
        Scanner scan = new Scanner(System.in);
        Vector <String> varios = new Vector<String>();
        vista view =  new vista();

        String instruccion ="";
        System.out.println();
        System.out.println("*********************BIENVENIDO AL TRADUCTO ESPAÑOL-INGLES-FRANCES*********************" );
        System.out.println();
        System.out.println();

        /***
         * Se lee un archivo txt (diccionario)
         */

        try{
            FileReader r = new FileReader("texto.txt");
            
            BufferedReader buffer = new BufferedReader(r);

            String temp ="";

            while(temp!=null){
                temp = buffer.readLine();
                if(temp == null){
                    break;
                }
                varios.add(temp);

            }
        }catch(Exception e){
            System.out.println("archivo no encontrado");
        }
      


        /***
         * Impresion de lo que hay en el archivo y se pasa la calculadora
         */

        System.out.println();
        System.out.println("Oraciones en el txt: ");
        System.out.println();
        for(int a =0;a<varios.size();a++){
            System.out.println(varios.get(a));
        }
        System.out.println("");
        /***
         * El usuario seleccionara el idioma origen y destino para cada oracion
         */

        int num = 0;
        int a = 0;
        while(a<varios.size()){
            num++;
            System.out.println(" TRADUCCION "+num+" : \n");

            /***
             * se elige el idioma de origen
             */

            int Ori = view.Menu("origen");
            int Dest = view.Menu("destino");

            /***
             * Confirmacion de los datos ingresados
             */
            String origen = "";
            String destino = "";
            if (Ori==1){origen="English";} else if (Ori==2){origen="Espanol";} else if (Ori==3){origen="Frances";}

            if (Dest==1){destino="English";} else if (Dest==2){destino="Espanol";} else if (Dest==3){destino="Frances";}

            System.out.println("\n El idioma de origen seleccionado fue : "+origen);
            System.out.println(" El idioma de destino seleccionado fue : "+destino+"\n");

            try{

                System.out.println("Traduccion completada correctamente \n");
                System.out.println(" Esta es la traduccion: "+esperanza.Calculo(varios.get(a),Ori,Dest) +" ");
                System.out.println();
            }catch(Exception e){
                System.out.println("ERROR: Vuelva a intentarlo");
                System.out.println();
            }
            a++;


        }
    }

}
